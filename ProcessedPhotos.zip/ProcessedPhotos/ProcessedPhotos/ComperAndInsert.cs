﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProcessedPhotos
{
    class ComperAndInsert
    {

        public void comperAndInsert(Dictionary<String, StudentStruct> DictionaryA, Dictionary<String, StudentStruct> DictionaryB)
        {

            Dictionary<String, StudentStruct> DictionaryTempA = new Dictionary<string, StudentStruct>();
            Dictionary<String, StudentStruct> DictionaryTempB = new Dictionary<string, StudentStruct>();
            Dictionary<String, StudentStruct> DictionaryFinall =new Dictionary<string, StudentStruct>();
            StudentStruct F = new StudentStruct();

            Console.WriteLine(" in comper");
            foreach (StudentStruct s in DictionaryA.Values)
            {   //its print the all student
                Console.WriteLine(s.toString());
            }

            Console.WriteLine(" -----------------------------------------");
            foreach (StudentStruct s in DictionaryB.Values)
            {   //its print the all student
                Console.WriteLine(s.toString());
            }
            Console.WriteLine(" -----------------------------------------");
            

            foreach (var key in DictionaryA.Keys)
            {
                Console.WriteLine("in foreach");
                if (DictionaryB.ContainsKey(key))
                {
                    Console.WriteLine("in if");
                    Console.WriteLine(DictionaryA[key].Name);
                    Console.WriteLine(DictionaryB[key].Name);
                    F.Name = DictionaryA[key].Name;
                    F.Id = DictionaryA[key].Id;
                    F.attendance = DictionaryB[key].attendance;
                    F.room = DictionaryB[key].room;
                    DictionaryFinall.Add(F.Name,F);
                }
                else if (!DictionaryB.ContainsKey(key))
                {
                    Console.WriteLine("in else");
                    Console.WriteLine(DictionaryA[key].Name);
                    //Console.WriteLine(DictionaryB[key].Name);
                    //write to error to log file
                    using (System.IO.StreamWriter fileName =
                    new System.IO.StreamWriter(@"C:\RollcallFile\Log\comperlog\log.txt", true))
                    {
                        fileName.WriteLine("The"+" "+ DictionaryA[key].Name+" "+ DictionaryA[key].Id + " " + " Is not exsist " + " " + DateTime.Now + Environment.NewLine);

                    }
                }
            }
            foreach (StudentStruct s in DictionaryFinall.Values)
            {   //its print the all student
                Console.WriteLine(s.toString());
            }

        }
    }
}
