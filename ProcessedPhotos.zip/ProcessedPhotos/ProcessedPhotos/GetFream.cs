﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing.Imaging;
using System.Drawing;
using System.IO;
using System.Data.Odbc;
using System.Collections;
using System.Threading;
using System.Windows;
using System.Net;
using RestSharp;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;



namespace ProcessedPhotos
{
    
    class GetFream 
    {

        private string path;
        private string status;
        private double id;
        private double roomNumber;
        private GetAllStudentFromDB callback;
        //static List<FileInfo> files = new List<FileInfo>();
        public GetFream(string pathdir, string stustat, Double ID, Double room, GetAllStudentFromDB callback)
        {
            path = pathdir;
            status = stustat;
            id = ID;
            roomNumber = room;
            this.callback = callback;
        }
        public GetFream(GetAllStudentFromDB callback)
        {
            path = pathdir;
            status = stustat;
            id = ID;
            roomNumber = room;
            this.callback = callback;
        }



        public string pathdir
        {
            get { return path; }
            set { path = value; }
        }

        public string stustat
        {
            get { return status; }
            set { status = value; }

        }

        public Double ID
        {
            get { return id; }
            set { id = value; }
        }

        public Double room
        {
            get { return roomNumber; }
            set { roomNumber = value; }
        }

        public void GetFreamFromdir()
        {
            Dictionary<String, StudentStruct> StudentApi = new Dictionary<String, StudentStruct>();
            StudentStruct api = new StudentStruct();
            StudentApi.Clear();

            path = "C:\\RollcallFile\\Room";
            string backupDir = @"C:\inetpub\wwwroot\TestRollcallPIc\";
            // Make a reference to a directory.
            DirectoryInfo di = new DirectoryInfo(path);
            DirectoryInfo[] diArr = di.GetDirectories();
            FileInfo[] fiArr = di.GetFiles("*.jpg", SearchOption.AllDirectories);
            try
            {
                // Get a reference to each directory in that directory.


                // Display the names of the directories.
                foreach (DirectoryInfo dri in diArr)
                {
                    //Console.WriteLine(dri.Name);
                    using (System.IO.StreamWriter ListDir =
                        new System.IO.StreamWriter(@"C:\RollcallFile\Log\ListDir\log.txt", true))
                    {
                        ListDir.WriteLine("From Roll-Call " + " " + DateTime.Now + Environment.NewLine + dri.Name);

                    }
                }
                //C:\Users\rotem\Desktop\student\Finall\Finallproject\ProcessedPhotos\ProcessedPhotos\Logs\ListFile
                //Get a reference to each file in that directory.
                foreach (FileInfo f in fiArr)
                {
                    //Console.WriteLine("The size of {0} is {1} bytes.", f.Name, f.Length);
                    using (System.IO.StreamWriter ListFile =
                        new System.IO.StreamWriter(@"C:\RollcallFile\Log\ListDir\log.txt", true))
                    {
                        ListFile.WriteLine("From Roll-Call " + " " + DateTime.Now + Environment.NewLine + "The size of {0} is {1} bytes.", f.Name, f.Length);

                    }
                }

                using (System.IO.StreamWriter file =
                new System.IO.StreamWriter(@"C:\RollcallFile\Log\ReadFromRollcallPIc\log.txt", true))
                {
                    file.WriteLine("start read " + " From Roll-Call " + " " + DateTime.Now + Environment.NewLine);

                }
            }

            catch (Exception e)
            {
                //write to error to log file
                using (System.IO.StreamWriter file =
                new System.IO.StreamWriter(@"C:\RollcallFile\Logs\ReadFromRollcallPIc\log.txt", true))
                {
                    file.WriteLine(e.Message + " From Roll-Call " + " " + DateTime.Now + Environment.NewLine);

                }
                //Console.WriteLine("Directory {0}  \n could not be accessed!!!!", di.FullName);
                return;
            }

                //Get each folder and check if the folder empty or not and if she not empty so the file copy to another folder            
                for (var i = 0; i < diArr.Length; ++i)
                    {
                        if (diArr[i].GetFiles().Length == 0) ; //Console.WriteLine(diArr[i].Name + "Empty");
                        else if (diArr[i].GetFiles().Length > 0)
                        {
                            //Console.WriteLine(diArr[i].Name + " Not Empty");
                            for (var j = 0; j < fiArr.Length; j++)
                            {
                            File.Copy(Path.Combine(diArr[i].FullName, fiArr[j].Name), Path.Combine(backupDir, fiArr[j].Name), true); ;
                            var httpWebRequest = (HttpWebRequest)WebRequest.Create("https://api.kairos.com/recognize");
                            httpWebRequest.ContentType = "application/json";
                            httpWebRequest.Method = "POST";
                            httpWebRequest.Headers.Add("app_id", "59a2a9c8");
                            httpWebRequest.Headers.Add("app_key", "eb02a53521025bfc8d46ef74f79f4349");

                    using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                    {

                        string json = "{\"image\":\"http://facerecoapp.cloudapp.net/TestRollcallPIc/" + fiArr[j] +"\"," +
                                            // "\"subject_id\":\"subtest1\"," +
                                            "\"gallery_name\":\"gallerytest1\"," +
                                            // "\"selector\":\"SETPOSE\"," +
                                            "\"symmetricFill\":\"true\"}";


                        streamWriter.Write(json);
                        streamWriter.Flush();
                        streamWriter.Close();
                    }
                        
                        var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                         // System.Console.WriteLine(result);
                         
                            //  Reading the status from the json
                           
                                JObject o = JObject.Parse(result);
                                Console.WriteLine(diArr[i] + " " + fiArr[j] + Environment.NewLine);
                                Console.WriteLine("Status: " + o["images"][0]["transaction"]["status"] + Environment.NewLine);
                                Console.WriteLine("subject: " + o["images"][0]["transaction"]["subject"] + Environment.NewLine);
                                Console.WriteLine("subject: " + o["images"][0]["transaction"]["gallery_name"] + Environment.NewLine);
                                api.room =Convert.ToString(diArr[i]);
                                api.Name = Convert.ToString(o["images"][0]["transaction"]["subject"]);                               
                                api.attendance= Convert.ToString(o["images"][0]["transaction"]["status"]);
                            if (!StudentApi.ContainsKey(api.Name))
                            {
                                StudentApi.Add(api.Name, api);
                            }
                            else
                            {
                                //write to error to log file
                                using (System.IO.StreamWriter fileName =
                                new System.IO.StreamWriter(@"C:\RollcallFile\Log\GetfreamName\log.txt", true))
                                {
                                    fileName.WriteLine("The user " + " " + api.Name +" "  + " Is exsist " + " " + DateTime.Now + Environment.NewLine);

                                }
                               
                               
                            }
                     
                                Console.WriteLine(api.room + " "+api.Name +" "+ api.attendance + Environment.NewLine);
                                Console.WriteLine("--------------------------------------------------------------" + Environment.NewLine);
                        }
                        
                     }
                    
                    }
                   }
                    callback(new GetAllStudentToStrucet(StudentApi));
                }
             }
}
