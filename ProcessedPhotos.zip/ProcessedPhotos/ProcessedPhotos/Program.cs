﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Drawing.Imaging;
using System.Drawing;
using System.IO;
using System.Data.Odbc;
using System.Collections;
using System.Threading;

namespace ProcessedPhotos
{
    class Program
    {
        static Dictionary<String, StudentStruct> dictionary;
        static Dictionary<String, StudentStruct> dictionaryApi;
        static Processedphotos PP = new Processedphotos();
        static GetFream GF = new GetFream(RequestHandlerApi);
        
        static void Main(string[] args)
        {

            PP.GetAllStudent(new GetAllStudentFromDB(RequestHander));
            Thread t1 = new Thread(new ThreadStart(GF.GetFreamFromdir));
            t1.Start();
            

        }
        static void RequestHander(GetAllStudentToStrucet reqStudent)
        {
            dictionary = reqStudent.Student;
            if(dictionaryApi != null)
            {
                ComperAndInsert c = new ComperAndInsert();
                c.comperAndInsert(dictionary,dictionaryApi);

            }

        }
        static void RequestHandlerApi(GetAllStudentToStrucet reqStudentApi)
        {
            dictionaryApi = reqStudentApi.Student;
            if(dictionary != null)
            {
                ComperAndInsert c = new ComperAndInsert();
                c.comperAndInsert(dictionary, dictionaryApi);
            }
        }
        
    }
}
